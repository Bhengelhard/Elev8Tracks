function init() {
  gapi.client.setApiKey('AIzaSyBZE6I-CUBBvPFqrZvUWRnslVc-UB3I9bY');
  //gapi.client.load('urlshortener', 'v1').then(makeRequest);
}