var Model = require('./base');

var Playlist = Model.extend({
	tableName: 'playlists'
});

module.exports = Playlist;